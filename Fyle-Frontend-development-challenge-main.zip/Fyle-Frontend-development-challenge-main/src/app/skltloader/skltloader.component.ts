import { Component } from '@angular/core';

@Component({
  selector: 'app-skltloader',
  // standalone: true,
  // imports: [],
  templateUrl: './skltloader.component.html',
  styleUrl: './skltloader.component.css'
})
export class SkltloaderComponent {

}

// import { Component } from '@angular/core';

// @Component({
//   selector: 'app-skltloader',
//   template: `
//     <div class="skeleton-loader">
//       <div class="line"></div>
//       <div class="line"></div>
//       <div class="line"></div>
//     </div>
//   `,
//   styles: [
//     `.skeleton-loader {
//       /* Customize the appearance of your skeleton loader here */
//       display: flex;
//       flex-direction: column;
//       width: 100%;
//       height: 200px;
//       background-color: #f2f2f2;
//       border-radius: 4px;
//       animation: shimmer 1s infinite alternate;
//     }

//     .line {
//       width: 100%;
//       height: 20px;
//       background-color: #e0e0e0;
//       margin-bottom: 5px;
//       border-radius: 2px;
//       animation: shimmer 1s infinite alternate;
//     }

//     @keyframes shimmer {
//       from {
//         background-position: 0 0;
//       }
//       to {
//         background-position: -200px 0;
//       }
//     }
//     `
//   ]
// })
// export class SkltloaderComponent{ }

